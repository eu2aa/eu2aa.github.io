/* Includes ------------------------------------------------------------------*/
#include "stm8s.h"
#include "stm8s_conf.h"
#include "si5351.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
unsigned char ProcFlag;
/* Private function prototypes -----------------------------------------------*/
void InputProcess(void);
/* Private functions ---------------------------------------------------------*/

#define TX_LEN  64

uint8_t tx_crc, tx_len, tx_idx;
extern uint8_t rx_crc, rx_len, rx_idx;
extern uint8_t rx_buf[];
extern uint8_t ucmd;
uint8_t tx_buf[TX_LEN];

extern unsigned char hz_100_flag;      
extern uint32_t reg;

uint8_t cur_freq = 0xff;

const uint8_t HexChar[] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

uint16_t CheckSum(uint8_t * ptr, uint8_t len)
{
  uint8_t a, b;
  uint16_t tmp;
  a = 0;
  b = 0;
  for( int i = 0; i < len; i++)
  {
    a = a + ptr[i];
    b = b + a;
  }
  tmp = a;
  tmp = tmp << 8;
  tmp = tmp | b;
  return tmp;
}

void SendMessage(uint8_t cl, uint8_t id, uint16_t len, const uint8_t *data)
{
  uint16_t tmp;
  
  tx_idx = 0;
  tx_len = 0;
  tx_buf[tx_len++] = 0xb5;
  tx_buf[tx_len++] = 0x62;
  tx_buf[tx_len++] = cl;
  tx_buf[tx_len++] = id;
  tx_buf[tx_len++] = len;
  tx_buf[tx_len++] = len >> 8;
  for(int i = 0; i < len; i++) tx_buf[tx_len++] = *data++;
  tmp = CheckSum(&tx_buf[2], len + 4);
  tx_buf[tx_len++] = tmp >> 8;
  tx_buf[tx_len++] = tmp;  
  UART1_ITConfig(UART1_IT_TXE, ENABLE);
}


void WriteReg(uint32_t reg)
{
  GPIOC->ODR &= ~GPIO_PIN_5;                                                    // CLK = 0
  GPIOC->ODR &= ~GPIO_PIN_4;                                                    // LE = 0
  for(uint8_t i = 0; i < 32; i++)
  {
    if(reg & 0x80000000) GPIOC->ODR |= GPIO_PIN_6; else GPIOC->ODR &= ~GPIO_PIN_6;    // DATA = X
    GPIOC->ODR &= ~GPIO_PIN_5;                                                  // CLK = 0
    reg = reg << 1;
    GPIOC->ODR |= GPIO_PIN_5;                                                   // CLK = 1        
  }
  GPIOC->ODR &= ~GPIO_PIN_5;                                                    // CLK = 0
  GPIOC->ODR |= GPIO_PIN_4;                                                     // LE = 1
}

volatile uint32_t rt;

uint32_t ReadReg(void)
{
  uint32_t reg = 0;

  GPIOC->ODR |= GPIO_PIN_5;                                                   // CLK = 1        
  rt = rt << 1;
  GPIOC->ODR &= ~GPIO_PIN_5;                                                    // CLK = 0
  
  for(uint8_t i = 0; i < 32; i++)
  {
    GPIOC->ODR |= GPIO_PIN_5;                                                   // CLK = 1        
    rt = rt << 1;
    if(GPIOC->IDR & GPIO_PIN_7) reg |= 0x01;
    GPIOC->ODR &= ~GPIO_PIN_5;                                                    // CLK = 0    
    reg = reg << 1;    
  }
  GPIOC->ODR &= ~GPIO_PIN_5;                                                    // CLK = 0
  return reg;
}


//const uint8_t cm[] = {0x00, 0x00, 0x00, 0x00, 0x32, 0x00, 0x00, 0x00, 0x80, 0x8d, 0x5b, 0x00, 0x80, 0x8d, 0x5b, 0x00, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x6f, 0x00, 0x00, 0x00};  
const uint8_t cm[] = {0x00, 0x01, 0x00, 0x00, 0x32, 0x00, 0x00, 0x00, 0x00, 0x1b, 0xb7, 0x00, 0x00, 0x1b, 0xb7, 0x00, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x6f, 0x00, 0x00, 0x00};  
const uint8_t cm1[] = {0xFF, 0xFF, 0x02, 0x03, 0x00, 0x00, 0x00, 0x00, 0x10, 0x27, 0x00, 0x00, 0x05, 0x00, 0xFA, 0x00, 0xFA, 0x00, 0x64, 0x00, 0x2C, 0x01, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x00, 0xC8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
const uint8_t cm2[] = {0x00, 0x00, 0x05, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x04, 0x00, 0x00};


uint8_t ct, stp;
uint8_t sel;
extern uint8_t nss;

uint32_t rd;

uint8_t ss_read;

void main(void)
{
  IWDG_Enable();
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
  IWDG_SetPrescaler(IWDG_Prescaler_256);
  IWDG_SetReload(0xff);                                                         // ~ 1,7 s
  IWDG_ReloadCounter();
  
  CLK->CKDIVR &= (uint8_t)(~CLK_CKDIVR_HSIDIV);
  CLK->CKDIVR |= (uint8_t)((uint8_t)CLK_PRESCALER_HSIDIV1 & (uint8_t)CLK_CKDIVR_HSIDIV);  
  CLK->ICKR |= CLK_ICKR_HSIEN;
  CLK->SWCR &= (uint8_t)(~CLK_SWCR_SWIEN);                                      // Disable switch interrupt

  GPIOA->ODR = GPIO_PIN_ALL;                                       
  GPIOA->DDR = 0;                                                               // Output
  GPIOA->CR1 = (uint8_t) (GPIO_PIN_ALL);                                        // PullUp
  GPIOA->CR2 = 0;                                                               // Interrupt    

  GPIOB->ODR = GPIO_PIN_4 | GPIO_PIN_5;                                       
  GPIOB->DDR = GPIO_PIN_4 | GPIO_PIN_5;                                         // Output
  GPIOB->CR1 = 0;
  GPIOB->CR2 = 0;                                                               // Interrupt      
  
  // PC4 - input PullUp
  // PC5 - output PP
  // PC6 - output PP
  // PC7 - output PP
  GPIOC->ODR = GPIO_PIN_3;                                       
  GPIOC->DDR = (uint8_t) (GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6);   // Output
  GPIOC->CR1 = (uint8_t) (GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6);   // PP
  GPIOC->CR2 = 0;                                                               // Interrupt    
  
  // Port D config
  // PD1 - input PU
  // PD2 - input PU
  // PD3 - input PU
  // PD4 - output PP
  // PD5 - input PU
  // PD6 - input PU
  GPIOD->ODR = 0;                                                               // Set to H
  GPIOD->DDR = GPIO_PIN_2 | GPIO_PIN_4;                                         // Output
  GPIOD->CR1 = (uint8_t) GPIO_PIN_ALL;                                          // PP | Pull up
  GPIOD->CR2 = 0;                                                               // Interrupt
  
  // Update - 20000 Hz
  TIM2->ARRH = (800 - 1) >> 8;
  TIM2->ARRL = (800 - 1) & 0xff;
  TIM2->IER |= (uint8_t)TIM2_IT_UPDATE;
  TIM2->CR1 |= TIM2_CR1_CEN;    
   
  // USART config
  UART1_Init((uint32_t)9600, UART1_WORDLENGTH_8D, UART1_STOPBITS_1, UART1_PARITY_NO, UART1_SYNCMODE_CLOCK_DISABLE, UART1_MODE_TXRX_ENABLE);
  UART1_Cmd(ENABLE);
  UART1_ITConfig(UART1_IT_RXNE, ENABLE);
  
  __enable_interrupt();
  
  ct = 0;
  stp = 0;
  
  while (1)
  {
    if(ProcFlag)
    {
      ProcFlag = 0;
      // GPS answer process
      if((rx_buf[0] == 0x05) && (rx_buf[1] == 0x01))
      { // ACK received
        if(stp == 0) stp = 1;
        else if(stp == 1) stp = 2;
        else if(stp == 2) stp = 3;
      }
    }
    if(hz_100_flag)
    {
      hz_100_flag = 0;
      IWDG_ReloadCounter();
      // Led process
      if((nss) && (stp == 6)) GPIOD->ODR |= GPIO_PIN_4;
      else
      {
        if(stp == 6)
        {
          if(ct == 0) GPIOD->ODR ^= GPIO_PIN_4;
        }
        else GPIOD->ODR &= ~GPIO_PIN_4;  
      }
      // Other timing process
      ct++;
      if(ct >= 100)
      {
        ct = 0;
        switch(stp)
        {
        case 0:
            SendMessage(0x06, 0x31, 32, &cm[0]);        
            break;
          case 1:
            SendMessage(0x06, 0x24, 36, &cm1[0]);        
            break;
          case 2:
//            SendMessage(0x06, 0x62, 20, &cm2[0]);        
            stp = 3;
            break;
          case 3:
            sel = ((GPIOA->IDR >> 1) & 0x07 );
            si5351_init(sel);
            stp = 4;
            break;
          case 4:
            
            ss_read = si5351_read(SI5351_REG_149_SSC);
            
            WriteReg(0x00400005);
            stp = 5;
            break;
          case 5:
            WriteReg(0x608c81fc);
            WriteReg(0xe9000013);
            WriteReg(0x10009e42);
            WriteReg(0x80000141);
            WriteReg(0x81770000);
            // 2-nd
            WriteReg(0x00400005);
            WriteReg(0x608c81fc);
            WriteReg(0xe9000013);
            WriteReg(0x10009e42);
            WriteReg(0x80000141);
            WriteReg(0x81770000);
            // Enable clock out
            GPIOD->ODR |= GPIO_PIN_2;
            stp = 6;
            break;
          case 6:
//            WriteReg(0x00000006);
//            rd = ReadReg();
            break;            
        }
      }
    }
  }
}
