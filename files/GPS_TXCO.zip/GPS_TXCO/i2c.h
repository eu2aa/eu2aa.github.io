#ifndef _I2C_H 
#define	_I2C_H  
 
#ifndef TRUE 
	#define TRUE	1 
	#define true	1 
#endif 
 
#ifndef FALSE 
	#define	FALSE	0 
	#define	false	0 
#endif 
 
#ifndef uchar 
#define uchar unsigned char 
#define	UCHAR uchar 
#endif 
 
#ifndef uint 
#define uint unsigned int 
#define	UINT uint 
#endif 
 
#ifndef ulong 
#define ulong unsigned long 
#define	ULONG ulong 
#endif 
 
#ifndef bool 
#define bool unsigned char 
#define	BOOL bool 
#endif 
 
#ifndef CONST 
#define	CONST const 
#endif 
  
void TestI2CAccess(void);
void I2C_EE_Init(void);

#endif 