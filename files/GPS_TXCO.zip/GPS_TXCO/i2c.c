#include "stm8s.h"
#include "stm8s_conf.h"

#include "i2c.h"   

#define SDA_H GPIOB->BSRR |= (1 << 9)
#define SDA_L GPIOB->BRR |= (1 << 9)
#define SCL_H GPIOB->BSRR |= (1 << 8)
#define SCL_L GPIOB->BRR |= (1 << 8)
#define SDA_read GPIOB->IDR & (1 << 9)

void TestI2CAccess(void)
{
  rprintfStr("I2C>Release SDA\n");
  
  RCC->APB2ENR |= RCC_APB2ENR_IOPBEN; // �������� ������������ �� PORTB
  
  GPIOB->BSRR |= (1 << 9) | (1 << 8);
  GPIOB->CRH &= 0xFFFFFF00; 
  GPIOB->CRH |= 0x00000077;   
  while(1)
  {
    GPIOB->BRR |= (1 << 8); // SCL = 0
    clock_delay(1000);
    GPIOB->BSRR |= (1 << 8); // SCL = 1
    clock_delay(1000);
    if(SDA_read) // Slave SDA (SDA == 1 ?)
    {
      GPIOB->BRR |= (1 << 8); // SCL = 0
      clock_delay(1000);
      GPIOB->BRR |= (1 << 9); // SDA = 0
      clock_delay(1000);
      GPIOB->BSRR |= (1 << 8); // SCL = 1
      clock_delay(1000);
      GPIOB->BSRR |= (1 << 9); // SDA = 1
      break;
    }
  }
}  

/*******************************************************************************
* Function Name  : I2C_Configuration
* Description    : EEPROM?�?�����
* Input          : None
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
void I2C_EE_Init(void)
{
  rprintfStr("I2C>Init\n");  
  TestI2CAccess();  
}

/*******************************************************************************
* Function Name  : I2C_delay
* Description    : ����??�
* Input          : None
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
static void I2C_delay(void)
{	
  volatile uint8_t i=5;
 
  while(i) i--; 
}

/*******************************************************************************
* Function Name  : I2C_Start
* Description    : None
* Input          : None
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
static FunctionalState I2C_Start(void)
{
  SDA_H;
  SCL_H;
  I2C_delay();
  if(!SDA_read)return DISABLE;	/* SDA���??�?��?�������?,��� */
  SDA_L;
  I2C_delay();
  SCL_L;
  I2C_delay();
  return ENABLE;
}

/*******************************************************************************
* Function Name  : I2C_Stop
* Description    : None
* Input          : None
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
static void I2C_Stop(void)
{
  SCL_L;
  I2C_delay();
  SDA_L;
  I2C_delay();
  SCL_H;
  I2C_delay();
  SDA_H;
  I2C_delay();
}

/*******************************************************************************
* Function Name  : I2C_Ack
* Description    : None
* Input          : None
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
static void I2C_Ack(void)
{	
  SCL_L;
  I2C_delay();
  SDA_L;
  I2C_delay();
  SCL_H;
  I2C_delay();
  SCL_L;
  I2C_delay();
}

/*******************************************************************************
* Function Name  : I2C_NoAck
* Description    : None
* Input          : None
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
static void I2C_NoAck(void)
{	
  SCL_L;
  I2C_delay();
  SDA_H;
  I2C_delay();
  SCL_H;
  I2C_delay();
  SCL_L;
  I2C_delay();
}

/*******************************************************************************
* Function Name  : I2C_WaitAck
* Description    : None
* Input          : None
* Output         : None
* Return         : ???��?:=1��ACK,=0��ACK
* Attention		 : None
*******************************************************************************/
static FunctionalState I2C_WaitAck(void) 	
{
  SCL_L;
  I2C_delay();
  SDA_H;			
  I2C_delay();
  SCL_H;
  I2C_delay();
  if(SDA_read)
  {
    SCL_L;
    return DISABLE;
  }
  SCL_L;
  return ENABLE;
}

 /*******************************************************************************
* Function Name  : I2C_SendByte
* Description    : ��?�?�?��????��?
* Input          : - SendByte: ??��?���?�
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
static void I2C_SendByte(uint8_t SendByte) 
{
  uint8_t i=8;

  while(i--)
  {
    SCL_L;
    I2C_delay();
    if(SendByte&0x80) SDA_H; else SDA_L;   
    SendByte<<=1;
    I2C_delay();
    SCL_H;
    I2C_delay();
  }
  SCL_L;
}


/*******************************************************************************
* Function Name  : I2C_ReceiveByte
* Description    : ��?�?�?��????��?
* Input          : None
* Output         : None
* Return         : I2C����???�?���?�
* Attention		 : None
*******************************************************************************/
static uint8_t I2C_ReceiveByte(void)  
{ 
  uint8_t i=8;
  uint8_t ReceiveByte=0;

  SDA_H;				
  while(i--)
  {
    ReceiveByte<<=1;      
    SCL_L;
    I2C_delay();
    SCL_H;
    I2C_delay();	
    if(SDA_read) ReceiveByte |= 0x01;
  }
  SCL_L;
  return ReceiveByte;
}

/*******************************************************************************
* Function Name  : I2C_WriteByte
* Description    : �?�?��?���?�
* Input          : - SendByte: ?��?����?�
*           	   - WriteAddress: ?��?��?��?
*                  - DeviceAddress: ��?�����(24c16?�SD2403)
* Output         : None
* Return         : ???��?:=1��??�?��,=0�??�
* Attention		 : None
*******************************************************************************/           

#define I2C_WAIT    4

FunctionalState I2C_EE_BufferWrite(u8* pBuffer, u32 WriteAddr, u8 NumByteToWrite) 
{		
  u8 num;
  rtimer_clock_t now, wt;
  
  if(!I2C_Start())return DISABLE;
  if(WriteAddr & 0x10000) I2C_SendByte(EPROM_ADDR | (1<<1)); else I2C_SendByte(EPROM_ADDR);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_SendByte(WriteAddr>>8);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_SendByte(WriteAddr & 0xff);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  while(NumByteToWrite--)     
  {   
    I2C_SendByte(*pBuffer++);
    I2C_WaitAck();   
  }     
  I2C_Stop(); 
  // �������� ���������� �������� ������
  rprintfStr("I2C>Write started. Wait end cycle...\n");
//  for(num = 0; num < I2C_WAIT; num++)
//  { // �������� � 5 ms  
    now = RTIMER_NOW();
    wt = now + (RTIMER_ARCH_SECOND / 50);
    rprintfStr("I2C>ACK wait start ");
    rprintfu32(now);
    rprintfStr("\n");
    while (RTIMER_CLOCK_LT(RTIMER_NOW(), wt))
    { // �������� ������
      I2C_Start();
      I2C_SendByte(EPROM_ADDR);
      if(I2C_WaitAck())
      {
        rprintfStr("I2C>ACK received at ");
        rprintfu32(RTIMER_NOW());
        rprintfStr("\n");
        I2C_Stop(); 
        return ENABLE;
      }
      I2C_Stop();
    }
    rprintfStr("I2C>No ACK\n");
    I2C_Stop();
    return DISABLE;
//  }
//  if(num == I2C_WAIT) return DISABLE;
//  return ENABLE;
}									 

FunctionalState I2C_EE_BufferWriteNoWait(u8* pBuffer, u32 WriteAddr, u8 NumByteToWrite) 
{		
  if(!I2C_Start())return DISABLE;
  if(WriteAddr & 0x10000) I2C_SendByte(EPROM_ADDR | (1<<1)); else I2C_SendByte(EPROM_ADDR);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_SendByte(WriteAddr>>8);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_SendByte(WriteAddr & 0xff);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  while(NumByteToWrite--)     
  {   
    I2C_SendByte(*pBuffer++);
    I2C_WaitAck();   // if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  }     
  I2C_Stop(); 
  return ENABLE;
}									 

FunctionalState I2C_EE_WaitReady(void) 
{		
  I2C_Start();
  I2C_SendByte(EPROM_ADDR);
  if(I2C_WaitAck())
  {
    I2C_Stop(); 
    return ENABLE;
  }
  I2C_Stop(); 
  return DISABLE; 
}									 

/*******************************************************************************
* Function Name  : I2C_ReadByte
* Description    : ?��?�???��?�
* Input          : - pBuffer: ?�?�?����?�
*           	   - length: ?�?�ƨ??�
*                  - ReadAddress: ?�?��?��?
*                  - DeviceAddress: ��?�����(24c16?�SD2403)
* Output         : None
* Return         : ???��?:=1��???���,=0�??�
* Attention		 : None
*******************************************************************************/          
FunctionalState I2C_EE_BufferRead(u8* pBuffer, u32 ReadAddr, u8 length)   
{		
  if(!I2C_Start())return DISABLE;
  if(ReadAddr & 0x10000) I2C_SendByte(EPROM_ADDR | (1<<1)); else I2C_SendByte(EPROM_ADDR);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_SendByte(ReadAddr>>8);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_SendByte(ReadAddr & 0xff);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_WaitAck();
  I2C_Start();
  I2C_SendByte(EPROM_ADDR | 0x01);
  I2C_WaitAck();
  while(length)
  {
    *pBuffer = I2C_ReceiveByte();
    if(length == 1)I2C_NoAck();
    else I2C_Ack(); 
    pBuffer++;
    length--;
  }
  I2C_Stop();
  return ENABLE;
}

FunctionalState I2C_EE_BufferCmp(u8* pBuffer, u32 ReadAddr, u8 length)   
{		
  if(!I2C_Start())return DISABLE;
  if(ReadAddr & 0x10000) I2C_SendByte(EPROM_ADDR | (1<<1)); else I2C_SendByte(EPROM_ADDR);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_SendByte(ReadAddr>>8);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_SendByte(ReadAddr & 0xff);
  if(!I2C_WaitAck()){I2C_Stop(); return DISABLE;}
  I2C_WaitAck();
  I2C_Start();
  I2C_SendByte(EPROM_ADDR | 0x01);
  I2C_WaitAck();
  while(length)
  {
    if(*pBuffer != I2C_ReceiveByte()) {I2C_Stop(); return DISABLE;}
    if(length == 1)I2C_NoAck();
    else I2C_Ack(); 
    pBuffer++;
    length--;
  }
  I2C_Stop();
  return ENABLE;
}

